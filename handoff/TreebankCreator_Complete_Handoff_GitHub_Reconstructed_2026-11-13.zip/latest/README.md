# UD Treebank Lab

> **Bhaashik Codex handoff:** See [Codex start guide](docs/CODEX_START_HERE.md), [conversation and decisions](docs/CONVERSATION_HANDOFF.md), and [original release provenance](docs/RELEASE_PROVENANCE.md). Historical commits preserve v0.1.0, v0.1.1, and v0.2.0.


## New in v0.3.4 — NVIDIA Titan V GPU setup profile

The **Titan V / Volta (sm_70)** needs an explicitly compatible PyTorch CUDA
wheel. Use the isolated `scripts/setup_titanv.sh` installer instead of a plain
`pip install torch`, which may select CUDA 13 and fail on this GPU.

```bash
# Preflight: no downloads, no system changes
bash scripts/setup_titanv.sh --dry-run

# Actual installation; Python 3.10-3.12 and working NVIDIA driver required
bash scripts/setup_titanv.sh --python python3.12
source scripts/activate_titanv.sh
python scripts/check_titanv.py   # confirms GPU and executes an sm_70 CUDA kernel

# Existing alignment files still take precedence; otherwise generate with GPU
udtl prepare-resources --config configs/corpus_titanv_example.yaml --dry-run
```

The profile creates **`.venv-titanv/`**, installs **PyTorch 2.14.1 from the
CUDA 12.6 wheel index**, and pins the torch version during subsequent pip
installation of SimAlign and the bilingual parser. It neither changes system
CUDA/Python nor downloads model weights during preflight. A separate
`--with-awesome` option attempts the legacy AWESOME-align package without
relaxing the torch constraint. The NVIDIA driver and compatible Python must
already be present. **[Titan V installation and runtime guide](docs/TITAN_V.md)**.

## New in v0.3.2 — configuration-driven conditional reuse and setup

The corpus YAML now controls resource availability, automatic import of already-existing
AWESOME/GIZA A3 alignments or Apertium streams, conditional generation only if data are
missing, and optional setup only when the tool is unavailable. All of this is **opt-in**;
the default remains `skip`, and external installers are never chosen automatically.

```bash
udtl prepare-resources --config configs/corpus_auto_resources_example.yaml --dry-run
udtl prepare-resources --config configs/corpus_auto_resources_example.yaml
udtl refine-corpus --config configs/corpus_auto_resources_example.yaml
```

**[Conditional resource setup](docs/CONDITIONAL_RESOURCE_SETUP.md)** ·
[Example configuration](configs/corpus_auto_resources_example.yaml) ·
[Raw import details](docs/EXTERNAL_RESOURCE_IMPORT.md)

## New in v0.3.1 — import existing external resources (no rerunning tools)

Existing AWESOME-align Pharaoh (`i-j`, zero-based) and GIZA++ `.A3.final`
(three-line blocks, one-based) alignments, and native Apertium morphological
streams can be converted in a standalone CPU-only stage. The importer validates
sentence IDs/order and token counts; Apertium ambiguity and optional AWESOME
alignment probabilities are preserved. **No aligner or analyzer is run.**

```bash
udtl import-resources --config configs/import_existing_resources.yaml
# Or: udtl import-alignments ... ; udtl import-apertium ...
```

See **[External resource import and formats](docs/EXTERNAL_RESOURCE_IMPORT.md)**.
Put the resulting `.jsonl` paths in the existing `refine-corpus` YAML under
`resources.alignment.mode: supplied` and `resources.apertium.mode: supplied`.

## External tool installer (v0.3.3)

A standalone, **explicit** setup script now checks/installs Apertium + lttoolbox,
SimAlign and the optional AWESOME-align neural aligner. It reuses existing
installations and can check or preview the plan without modifying anything.
The AWESOME-align CLI is also supported as an optional alignment generation
backend (`backend: awesome` or opt-in fallback `backend: auto`). Existing
supplied alignment and Apertium files still **take precedence**, with no
installation or model execution.

```bash
bash scripts/install_linguistic_tools.sh --apertium --aligner simalign --dry-run
bash scripts/install_linguistic_tools.sh --apertium --aligner simalign
bash scripts/install_linguistic_tools.sh --aligner awesome --check
```

See [external tool installation](docs/EXTERNAL_TOOL_INSTALL.md) and
[conditional resource setup](docs/CONDITIONAL_RESOURCE_SETUP.md). Apertium
language-specific compiled analyzers are separate resources and must be
provided or installed explicitly.

## New in v0.2.0 — bilingual UD-guided neural parser and Kaggle T4×2 launcher

**[Bilingual training documentation](docs/BILINGUAL_TRAINING.md)** · **[Kaggle two-GPU setup](docs/KAGGLE_DUAL_T4.md)** · **[Kaggle notebook](notebooks/Kaggle_Dual_T4.ipynb)**

The bilingual trainer consumes **Hindi gold UD and corresponding unannotated target sentences together**, with automatically generated word-alignment evidence. Its Hindi source-graph features and target language representations interact through trainable alignment-aware parallel layers; only the **target dependency parsing head** predicts a tree. The underlying XLM-R transformer is frozen and word embeddings may be cached across epochs and languages. This is **not** the standard Trankit `TPipeline` API, which remains separately available as a baseline.

```bash
# Install optional pretrained Hugging Face encoder cache support
python -m pip install -e '.[bilingual]'

# Simple 3-sentence smoke test (not a useful trained parser)
udtl cache-bilingual --config configs/bilingual_marathi_demo.yaml
udtl train-bilingual --config configs/bilingual_marathi_demo.yaml
udtl predict-bilingual --config configs/bilingual_marathi_demo.yaml

# For real 13-language runs, generate YAMLs from your JSONL manifest (see docs)
udtl launch-bilingual --configs configs/generated/*.yaml --gpus 0,1 --dry-run
udtl launch-bilingual --configs configs/generated/*.yaml --gpus 0,1
```

The launcher runs one isolated Python process per GPU, shares the frozen Hindi embedding cache, handles a queue of language jobs, and resumes from each language's checkpoints. Kaggle T4×2 means **2 × 16 GB independent GPUs**, not a shared 32-GB GPU. Any interruptions require restoring checkpoints and embeddings to persistent paths from saved outputs or cloud storage.

**Research limitations:** alignment weights are uncertain heuristics; weak projected supervision may reinforce systematic errors. Independent manually annotated target-language gold is essential for credible evaluation. The new bilingual parser provides source-guided dependency trees and provisional aligned-source UPOS, not full Apertium-integrated FEATS, target-only parsing, or constituency trees. The new GPU architecture and previous runtime projections are **not yet GPU-benchmarked**.

---

**Resumable cross-lingual Universal Dependencies (UD) treebank bootstrapping, using alignment projection, optional finite-state morphology, grammar-informed soft constraints, and trainable multilingual parsers.**

Status: **research prototype v0.3.4, with offline-tested corpus refinement, projection, and small synthetic bilingual training paths.** Projection, refinement, training with mock cached embeddings, evaluation, visualization, and regression tests were exercised offline. Real XLM-R downloads and GPU fine-tuning were **not** run in this environment; verify each optional backend before launching a large experiment.

This tool **does not use LLMs to generate annotations**. An explicitly optional, conventional neural machine-translation adapter (IndicTrans2) can produce target *sentences* from a UD source treebank; it does not produce trees. Real parallel data may be supplied instead.

## First success in five commands (generic Ubuntu VM, CPU, no model download)

Python **3.10–3.12 recommended**. From the repository root:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[test]'
python -m pytest
bash scripts/demo.sh
```

Open **`runs/marathi_demo/preview.html`** in a browser. You will find projected Marathi CoNLL-U, annotation metadata, training splits, metrics, and SVG dependency graphs.

The **3 demonstration sentences** have *human-authored alignments* and deliberately simple structures. High scores on the demo have **zero statistical significance** for general treebank accuracy.

## Lightning AI Pro: setup, cloud data/model storage, start/sleep/resume

**Detailed guide:** [`docs/LIGHTNING_AI_PRO.md`](docs/LIGHTNING_AI_PRO.md).

For **Lightning AI Studios**, use the existing managed Python environment: **do not run
`python -m venv` or `scripts/setup_vm.sh` in a Studio**. Once you have opened a CPU Studio
and uploaded/extracted this ZIP into `/teamspace/studios/this_studio/`:

```bash
cd /teamspace/studios/this_studio/ud-treebank-lab
bash scripts/setup_lightning.sh
# Switch to a GPU only when the models and data are ready.
```

If you have **Google Drive/Dropbox remotes configured with rclone** (or have copied your
existing `rclone.conf` from Ubuntu into `~/.config/rclone/`), use:

```bash
bash scripts/cloud_io.sh pull-data drive:UDTreebankLab/data
bash scripts/cloud_io.sh pull-models dropbox:UDTreebankLab/models
# On a completed/paused experiment:
bash scripts/cloud_io.sh push-runs dropbox:UDTreebankLab/backups/run_2026-11-06
```

Use one or both services; substitute your remote/folder names. This uses **non-deleting
`rclone copy`** and *local* working files rather than training through a network mount.
Downloaded local HF model snapshots can be referenced by relative YAML fields such as
`../assets/models/xlm-roberta-base`; this release resolves such model directories
relative to the configuration file. A ready-to-edit staging preset is provided at
`configs/hindi_to_marathi_lightning_cloud.yaml`. Save a full `runs/` backup before **Sleep** to
protect checkpoint state. Lightning Studios persist files/packages across Sleep,
but running training processes are stopped. See the guide for detailed browser/CLI
instructions, OAuth/headless setup, billing checks, and restart steps.

## Actual Hindi → target-language workflow

1. Get Hindi HDTB (and read the original treebank license):

   ```bash
   udtl fetch-ud --treebank UD_Hindi-HDTB --short-name hi_hdtb --out data/ud_hindi_hdtb
   ```

2. On a GPU VM, install optional backends:

   ```bash
   # Choose a torch/CUDA wheel matching the VM FIRST: https://pytorch.org/get-started/locally/
   pip install -e '.[align,translate,hf]'
   # Optionally install parser backend (in a compatible environment):
   pip install -e '.[trankit]'
   ```

3. Edit `configs/hindi_to_marathi.yaml` to use either your own target `targets` JSONL / `alignments` JSONL, **or** automatic `translate` plus SimAlign.

4. Run (including train when configured):

   ```bash
   udtl run configs/hindi_to_marathi.yaml
   # Repeat this identical command to resume after interruption.
   ```

5. Check `runs/marathi_full/pair_01/silver.conllu`, `metadata.jsonl`, `training_data/`, and the model directory. Provide an *independent manually annotated target-language* dev/test corpus before quoting real LAS.

The `configs/hindi_to_marathi.yaml` preset uses the checkpointable HF parser, which learns UPOS and dependency labels/heads from **XLM-RoBERTa-base** features. Trankit is a documented alternative, with a joint POS/morph/dependency head; its **internal** mid-epoch restart depends on the Trankit version. See `docs/TRAINING.md`.

**Important:** IndicTrans2 model downloads can require Hugging Face access conditions and may not be available on an anonymous VM. Its `trust_remote_code=True` setting executes third-party model code; use only models you trust. Model/torch/transformers compatibility may need a dedicated environment.

## What is implemented

| Function | Support |
|---|---|
| Source UD, one or multiple treebanks | CoNLL-U; pooling multiple source-target pairs in one YAML run |
| Sentence-level pairing | Stable `sent_id`; alternative: parse sentence-aligned text with Stanza |
| Word alignment | SimAlign mBERT/XLM-R, external alignments (e.g. awesome-align/eflomal), lexicon baseline, demo-only identity |
| Automatic translation | Optional IndicTrans2 Indic→Indic model; alternative pretranslated pairs |
| UD annotation transfer | UPOS, deprels/heads, partial morphology from target analyzer; language-specific soft grammar rules |
| Many-to-many / missing alignments | Source-anchor selection, ancestor projection, weak fallback attachments |
| Structural correctness | Maximum-weight *single-root arborescence*, checked against UD tree invariants |
| Source/target morphology | Limited target-side Apertium `lt-proc` FST analyzer bridge; external morphology JSONL |
| Synthetic sentences | Inflected, linguist-authored bilingual templates with fixed UD structure |
| Training | Trankit custom `posdep`; HF XLM-R encoder + POS/dependency head, optional encoder tuning; Stanza dataset export |
| Constituency trees | **Separate**, optional Stanza constituency *inference* for languages with a pretrained model; not derived from UD |
| Checkpoint/resume | Per-sentence JSONL for translation/alignment/projection; HF trainer step/optimizer/epoch checkpoints; Trankit completed-stage skip |
| Evaluation | Strict UPOS, UAS, LAS, FEATS/lemma exact accuracy, root, relation confusion, distance buckets; optional official UD scorer |
| Visualization | Offline HTML with inline SVG dependency arcs, projection-quality distribution and errors |
| Reproducibility | YAML configs, seed, input fingerprints, run manifest, source metadata, tests |

## Main commands

```bash
udtl --help
udtl languages
udtl fetch-ud --out data/ud_hindi_hdtb
udtl run examples/demo.yaml
udtl align --source SOURCE.conllu --targets TARGETS.jsonl --out LINKS.jsonl
udtl project --source SOURCE.conllu --targets TARGETS.jsonl \
  --alignments LINKS.jsonl --out SILVER.conllu --metadata PROVENANCE.jsonl
udtl prepare --silver SILVER.conllu --metadata PROVENANCE.jsonl --out train_data
udtl train-trankit --train train_data/train.conllu --dev train_data/dev.conllu --out model_trankit
udtl train-hf --train train_data/train.conllu --dev train_data/dev.conllu --out model_hf
udtl predict-hf --model-dir model_hf --input TARGET_INPUT.conllu --out PRED.conllu
udtl evaluate --gold GOLD_TEST.conllu --pred PRED.conllu --out metrics.json
udtl visualize --input PRED.conllu --metrics metrics.json --out view.html
udtl synthesize --templates examples/synthetic_templates.json --out synth_data
```

> `SOURCE.conllu` needs gold/basic UD heads. `TARGET_INPUT.conllu` for `predict-hf` needs tokenized words but does not require gold annotations. The official UD scorer is strongly recommended for publishable results, especially when tokenization differs.

## Documentation

- [`docs/INSTALL.md`](docs/INSTALL.md): generic Ubuntu/GPU VM installation and resumption.
- [`docs/LIGHTNING_AI_PRO.md`](docs/LIGHTNING_AI_PRO.md): complete Lightning AI Pro Studio creation, GPU start/sleep, Google Drive/Dropbox, remote model snapshots, backup and resume.
- [`docs/CORPUS_REFINEMENT.md`](docs/CORPUS_REFINEMENT.md): optional existing alignment/Apertium/UniMorph data and corpus-level repair.
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md): dependency projection algorithm, constraints, confidence, reference approaches.
- [`docs/DATA.md`](docs/DATA.md): exact input formats; parallel corpora, Apertium, multi-source, synthetic templates.
- [`docs/TRAINING.md`](docs/TRAINING.md): Trankit, Hugging Face and Stanza, checkpoint guarantees, evaluation design.
- [`docs/EVALUATION.md`](docs/EVALUATION.md): gold vs silver, metrics, leakage, error analysis, offline visualization.
- [`docs/LANGUAGES.md`](docs/LANGUAGES.md): all 22 Eighth Schedule languages and IndicTrans codes; priorities and risks.
- [`docs/LIMITATIONS.md`](docs/LIMITATIONS.md): scientific/engineering limitations and prioritized improvements.
- [`docs/REFERENCES.md`](docs/REFERENCES.md): papers, repositories, model cards, UD license notes.
- [`docs/CHANGELOG.md`](docs/CHANGELOG.md): release changes, including Lightning deployment additions.

## v0.3.0 — Corpus-wide alignment refinement (opt-in, CPU-only)

Before bilingual neural training, the new `refine-corpus` stage can compare
all Hindi–target sentence pairs to detect repeated lexical patterns, suspicious
function-word matches, NULL or bound realizations, and possible target affixes.
It accepts **existing** alignments, Apertium analyses, and UniMorph tables;
none of these tools or downloads runs by default. See
[`docs/CORPUS_REFINEMENT.md`](docs/CORPUS_REFINEMENT.md).

```bash
bash scripts/demo_corpus.sh
udtl refine-corpus --config configs/corpus_marathi_supplied.yaml
# Optional opt-in corpus stage with bilingual trainer:
# udtl train-bilingual --config configs/bilingual_marathi_corpus.yaml
```

This stage provides **uncalibrated silver hypotheses**, not validated gold
word or morpheme alignments. Apertium/UniMorph candidate lattices and inferred
function-affix statistics are saved separately for review.

## Outputs

```text
runs/<target>/
  pair_01/
    target.jsonl               # when translation was requested
    alignments.jsonl           # when alignment was requested
    projection.stage.jsonl     # resume cache (do not delete during a run)
    silver.conllu              # UD basic dependencies (silver)
    metadata.jsonl             # confidence, coverage, arc provenance
    *.state.json               # input-aware stage signature
  pair_02/ ...                 # when configured
  training_data/
    train.conllu
    dev.conllu
    test.conllu                # only if independent gold test supplied
    split_report.json
  model_hf/
    last.pt                    # optimizer, model, RNG, epoch, batch position
    best.pt
    history.json
  model_trankit/               # if Trankit chosen
  run_manifest.json
```

## Research integrity, usage, and licenses

This is a *starter corpus builder*, not an automatic generator of gold-quality treebanks. A silver split is not a gold benchmark. **Neither a perfect demo result nor a held-out silver dev LAS establishes target-language accuracy.** Linguistically checked data, error review, appropriate licensing and independent gold evaluation are necessary.

**Hindi HDTB is CC BY-NC-SA 4.0** (noncommercial/share-alike restrictions). This project's own **code is MIT**; that does **not** relicense Hindi HDTB, translations, derived annotations, or other model/dataset artifacts. Review the licenses and redistribution terms of every source corpus and model before releasing derivative treebanks or checkpoints.

The selected model licenses and actual training runtime on a VM have **not** been independently verified by executing full GPU training here. The package is designed to make those checks and experiments straightforward.
