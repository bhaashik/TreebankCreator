GitHub reconstruction, not an exact replica of the local ChatGPT ZIP.
Original local full ZIP captures 75 recoverable files, including duplicates
and intermediate attachments not all committed to GitHub. GitHub copy
reconstructs source versions, history and latest key documents.
Conversation document is a reconstructed handoff, not a verbatim export.
